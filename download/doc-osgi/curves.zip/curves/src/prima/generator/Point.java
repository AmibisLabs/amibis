/**
 * 
 */
package prima.generator;

/**
 * @author reignier
 *
 */
public class Point {
	
	private double x ;
	private double y ;
	
	public Point()
	{
		this.x = 0.0 ;
		this.y = 0.0 ;
	}
	
	public Point(double x, double y)
	{
		this.x = x ;
		this.y = y ;
	}
	
	/**
	 * @return Returns the x.
	 */
	public double getX() {
		return x;
	}
	/**
	 * @param x The x to set.
	 */
	public void setX(double x) {
		this.x = x;
	}
	/**
	 * @return Returns the y.
	 */
	public double getY() {
		return y;
	}
	/**
	 * @param y The y to set.
	 */
	public void setY(double y) {
		this.y = y;
	}
	
	public String toString()
	{
		String result = "("+x+","+ y + ")";
		return result ;
	}
}
