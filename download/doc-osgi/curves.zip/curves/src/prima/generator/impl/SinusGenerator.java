/**
 *
 */
package prima.generator.impl;

import prima.generator.Generator;
import prima.generator.Point;

/**
 * @author reignier
 *
 */
public class SinusGenerator implements Generator {

	/** current point on the sinus fonction */
	private Point current ;

	/** delta x between two generated points */
	private double step ;

	/** new_y = sin(w*x) ; */
	private double w ;

	public SinusGenerator()
	{
		current = new Point(0.0, 0.0);
		step = Math.PI / 10.0 ;
		w = 1.0 ;
	}

	/* (non-Javadoc)
	 * @see prima.generator.Generator#generateNext()
	 */
	public Point generateNext() {
		double newX = current.getX()+step;

		current.setX(newX) ;
		current.setY(Math.sin(newX*w));

		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
		}

		return current;
	}

	/**
	 * @return Returns the w.
	 */
	public double getW() {
		return w;
	}

	/**
	 * @param w The w to set.
	 */
	public void setW(double w) {
		this.w = w;
	}

	/* (non-Javadoc)
	 * @see prima.generator.Generator#f(double)
	 */
	public double f(double x) {
		// TODO Auto-generated method stub
		return Math.sin(x*w);
	}
}
