/**
 * 
 */
package prima.generator;

/**
 * Function generator
 * @author reignier
 *
 */
public interface Generator {
	
	/** 
	 * Generates the next point on the curve
	 * @return
	 */
	public Point generateNext();
	
	/**
	 * Returns the value of the function on a single point
	 * @param x the x coordinate
	 * @return the function value
	 */
	public double f(double x) ;
}
