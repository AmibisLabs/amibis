/**
 * 
 */
package prima.display;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import prima.generator.Generator;
import prima.generator.Point;

/**
 * @author reignier
 *
 */
public class GraphDisplay {
	
	/** The chart of the membership function */
	private JFreeChart chart = null ;
	
	private JFrame frame = null ;
	
	private JPanel graphContent = null ;
	private XYSeries series = null ;
	private Generator generator;
	private JPanel interactive ;
	private JTextField xField ;
	private JLabel yField ;
	
	public GraphDisplay()
	{
		graphContent = new JPanel() ;
	    series = new XYSeries("Function Display");
	    
	    series.setMaximumItemCount(20) ;

	    XYDataset xyDataset = new XYSeriesCollection(series) ;
		chart = ChartFactory.createXYLineChart("function", "x", "y", xyDataset, PlotOrientation.VERTICAL, true, true, false) ;

		ChartPanel chartPanel = new ChartPanel(chart);
		graphContent.add(chartPanel) ;
		
		chartPanel.setPreferredSize(new java.awt.Dimension(500, 270)) ;
		frame = new JFrame("Function Display") ;
		frame.add(graphContent) ;
		
		interactive = new JPanel();
		interactive.setLayout(new FlowLayout());		
		interactive.add(new JLabel("x=")) ;
		xField = new JTextField(5);
		interactive.add(xField) ;
		interactive.add(new JLabel("f(x)=")) ;
		yField = new JLabel() ;
		interactive.add(yField);
		xField.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						int x = Integer.parseInt(xField.getText());
						compute(x);
					}
			
				});
		
		frame.add(interactive, BorderLayout.SOUTH);		
		frame.pack() ;	
		frame.setVisible(true) ;
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	/**
	 * adds a new point to the displayed graph
	 * @param point the new point !
	 */ 
	public void addPoint(Point point)
	{
		series.add(point.getX(), point.getY());
	}

	/**
	 * @return Returns the generator.
	 */
	public Generator getGenerator() {
		return generator;
	}

	/**
	 * @param generator The generator to set.
	 */
	public void setGenerator(Generator generator) {
		this.generator = generator;
	}
	
	/**
	 * This method is called when the user wants to compute the value of the function
	 * on a particular point. 
	 * @param x the x coordinate given by the user
	 */
	public void wantCompute(double x)
	{
		// this will be complexified on the distributed version !
		compute(x);
	}
	
	/** 
	 * Computes the value of the function on a single point and displays it in the interface
	 * @param x 
	 */
	public void compute(double x)
	{
		double y = generator.f(x);
		yField.setText(new Double(y).toString()) ;
	}
}
