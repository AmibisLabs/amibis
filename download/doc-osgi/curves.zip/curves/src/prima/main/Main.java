/**
 * 
 */
package prima.main;

import prima.control.WeightControl;
import prima.display.GraphDisplay;
import prima.generator.Generator;
import prima.generator.impl.SinusGenerator;

/**
 * @author reignier
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Generator generator = new SinusGenerator() ;

		GraphDisplay graphDisplay = new GraphDisplay() ;
		WeightControl control = new WeightControl();
		graphDisplay.setGenerator(generator);
		control.setGenerator((SinusGenerator) generator) ;
		
		while (true)
		{
			graphDisplay.addPoint(generator.generateNext());
		}
	}
}
