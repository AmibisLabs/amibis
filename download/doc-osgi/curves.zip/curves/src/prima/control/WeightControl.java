/**    
 * author: Patrick Reignier (Prima/Gravir)
 *
 * This program is free software; you can redistribute it and/or 
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
**/
package prima.control;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import prima.generator.impl.SinusGenerator;

/**
 * @author Patrick Reignier (Prima/Gravir)
 *
 */
public class WeightControl extends JFrame {
	private SinusGenerator generator ;
	private JSlider slider ;
	
	public WeightControl()
	{
		slider = new JSlider(0,100) ;
		slider.setSize(100,50);
		add(slider);
		pack() ;
		setVisible(true);
		
		slider.addChangeListener(new ChangeListener()
				{
					public void stateChanged(ChangeEvent e) {
						double value = (double) slider.getValue()/100.0 ;
						generator.setW(value);
					}
			
				});
	}

	/**
	 * @return Returns the generator.
	 */
	public SinusGenerator getGenerator() {
		return generator;
	}

	/**
	 * @param generator The generator to set.
	 */
	public void setGenerator(SinusGenerator generator) {
		this.generator = generator;
	}
}
